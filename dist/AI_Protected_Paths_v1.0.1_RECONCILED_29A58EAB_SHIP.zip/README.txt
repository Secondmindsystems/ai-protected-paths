# AI Protected Paths

File-level local commit governance for AI-assisted coding workflows.

AI Protected Paths helps stop AI tools, rushed commits, or accidental changes
from silently entering Git history through sensitive paths in your repo.

Normal files commit normally. Protected files require a local approval token
before the normal commit path can proceed. Hook-governed commit decisions can
write local proof receipts under `proofs/packets/`.

## Buyer Fast Path

1. Extract the ZIP anywhere on your computer.

   Example:

   ```text
   C:\Tools\AI_Protected_Paths
   ```

2. Open PowerShell inside the Git repo you want to protect.

   ```powershell
   cd C:\YourProject
   ```

3. Install the hook from the package path.

   ```powershell
   C:\Tools\AI_Protected_Paths\protected-paths.cmd install
   ```

4. Try a normal commit. It should pass.

5. Try a protected commit under one of the default protected paths,
   `governance/` or `hooks/`. It should block until you authorize it.

6. Authorize the protected change.

   ```powershell
   C:\Tools\AI_Protected_Paths\protected-paths.cmd authorize --reason "reviewed protected change"
   ```

   Do not stage `approvals/APPROVAL_TOKEN.txt`.
   Do not run `git add approvals/`.
   Stage only the actual files you intended to commit.

7. Commit again, then view the latest local proof receipt.

   ```powershell
   C:\Tools\AI_Protected_Paths\protected-paths.cmd proofs latest
   ```

Read `QUICKSTART.txt` first if you want the shortest buyer walkthrough. The
rest of this README is the technical reference.

AI coding agents can modify files, stage changes, and create commits. GitHub
protects branches, but it does not protect specific files inside those branches
before a local commit is created. AI Protected Paths adds a local Git pre-commit
check so selected files or folders cannot be committed through the normal commit
path unless an approval token is present.

GitHub protects branches.
AI Protected Paths governs files.

## What It Does

AI Protected Paths checks staged files at commit time.

1. You list protected paths in `governance/protected_paths.txt`.
2. The Git pre-commit hook reads the staged file list.
3. If `approvals/APPROVAL_TOKEN.txt` is staged, the commit is blocked.
4. If a staged file starts with a protected path and no approval token exists,
   the commit is blocked.
5. If the protected path config cannot be resolved, the commit is blocked.
6. If an approval token exists and is not staged, the commit is allowed and the
   token is consumed.
7. The hook writes a local proof receipt for governed commit decisions,
   including blocked commits.

This is governance friction for commit workflows. It is not a security boundary.

## Package Launchers

The release package includes these root launchers:

```text
protected-paths.cmd
protected-paths.ps1
```

Use `protected-paths.cmd` on Windows when possible. Use
`protected-paths.ps1` when you want to run the PowerShell launcher directly.

The CLI supports:

```text
install
verify
doctor
status
authorize [--reason <text>]
proofs latest
protect list
protect add <path>
protect remove <path>
```

The CLI is a control surface. The Git hook remains the commit-time enforcement
authority.

## First-Run Flow A: Package Inside The Target Repo

Extract or copy this package into the root of the Git repository you want to
protect.

This simple model leaves package/tooling files visible in `git status`. That is
expected, not corruption. Do not stage package files unless you intentionally
choose to vendor the tool in the repo.

```powershell
cd C:\path\to\target-repo
.\protected-paths.cmd install
.\protected-paths.cmd verify
```

PowerShell launcher form:

```powershell
powershell -ExecutionPolicy Bypass -File .\protected-paths.ps1 install
```

## First-Run Flow B: Package Outside The Target Repo

You may keep the package outside the target repo. This is recommended for a
cleaner buyer repo. In that case, `cd` into the target Git repo first, then
invoke the package launcher by absolute path.

```powershell
cd C:\path\to\target-repo
C:\path\to\AI_Protected_Paths\protected-paths.cmd install
C:\path\to\AI_Protected_Paths\protected-paths.cmd verify
```

Repo-sensitive commands act on the current Git working directory. A random
non-repo directory does not become a target repository automatically.

## Fallback Installer Scripts

The direct installer scripts remain available. They are package-aware, but the
package launcher remains the recommended control surface. Run fallback
installers from the target Git repo and invoke them by package path.

### Windows

```powershell
powershell -ExecutionPolicy Bypass -File C:\path\to\AI_Protected_Paths\install.ps1
```

### macOS / Unix Shell

```bash
chmod +x /path/to/AI_Protected_Paths/install.sh
/path/to/AI_Protected_Paths/install.sh
```

The Unix install path copies `hooks/pre-commit` into `.git/hooks/pre-commit`
and marks the installed hook executable. Native Linux validation is pending
until a real Linux host validation exists.

## Default Protected Paths

The shipped default config protects the product's own governance and hook files:

```text
governance/
hooks/
```

These defaults demonstrate self-protection without surprising users by blocking
common application folders. Edit `governance/protected_paths.txt` or use
`protected-paths protect add <path>` to add paths that matter in your repo.

Example protected paths:

```text
auth/
payments/
migrations/
infra/
.env
```

Use one path per line. Blank lines and lines starting with `#` are ignored.
Path matching is prefix-based, so `auth/` protects files under `auth/`.

## Approval Token Behavior

To approve a protected change, create this local file:

```text
approvals/APPROVAL_TOKEN.txt
```

Preferred CLI form:

```powershell
.\protected-paths.cmd authorize --reason "reviewed protected path change"
```

Current v1 behavior is intentionally simple: the hook checks whether the token
file exists. It does not parse the token contents, bind the token to a specific
commit, or implement cryptographic approval. When the token allows a protected
commit, the hook deletes it after writing the proof receipt.

Create the token only when you are approving a protected commit. Do not stage
`approvals/APPROVAL_TOKEN.txt`; stage only the protected files intended for
commit. If a token exists during an unprotected commit, it is not consumed
because it was not needed.

Do not run `git add approvals/`. `approvals/APPROVAL_TOKEN.txt` is local
runtime approval. `approvals/APPROVAL_TOKEN_TEMPLATE.txt` is reference material,
not the approval token.

If the approval token is staged accidentally, unstage it before committing:

```text
git reset approvals/APPROVAL_TOKEN.txt
```

Installers add `approvals/APPROVAL_TOKEN.txt` to the target repo `.gitignore`
without overwriting existing ignore rules.

Protected files are blocked even on the first commit of a new repository unless
the approval token exists. A first commit with no protected hits is allowed.

## Verify, Doctor, And Status

Use these read-only checks after installation:

```powershell
.\protected-paths.cmd status
.\protected-paths.cmd doctor
.\protected-paths.cmd verify
```

`verify` is a non-destructive state check. `FAIL` means something required is
missing or unsafe, such as no target Git repo, missing hook/config assets, or a
staged approval token. `WARN` is a warning state, not a blocking failure by
itself. `verify` does not prove end-to-end commit behavior.

## Proof Receipts

The hook writes local proof receipts under:

```text
proofs/packets/
```

Proof receipts record the hook outcome, staged files, protected hits, repo
metadata, and reason. Installers add `proofs/` to the target repo `.gitignore`,
so receipts remain local unless you export, archive, or collect them outside
this package.

View the latest local receipt:

```powershell
.\protected-paths.cmd proofs latest
```

If no proof packet exists yet, that is normal before the hook has emitted one.
`proofs latest` summarizes observed local JSON files only. It does not perform
schema validation and does not repair malformed proof files.

## Common Recovery Notes

If a protected commit blocks because the approval token is missing, create an
approval token with `protected-paths authorize --reason "brief reason"`, do not
stage the token, stage only the intended files, and retry the commit.

If `authorize` says an approval token already exists, finish or remove the
pending token first. The CLI refuses to overwrite it.

If an approved commit reports that the token could not be consumed, inspect or
remove `approvals/APPROVAL_TOKEN.txt`, confirm it is not staged, and retry when
the repo state is clean.

If a command says it is not inside a Git repo, `cd` into the target repo and run
the command again. In Flow B, keep the current directory as the target repo and
invoke the package launcher by absolute path.

## Windows Download / Script Policy Note

Downloaded ZIP files or scripts can trigger Windows script policy,
SmartScreen, or Mark-of-the-Web prompts. Verify the package source and hash, then
follow your local policy for downloaded scripts. This release does not claim code
signing or SmartScreen reputation.

## Manual Uninstall

There is no CLI `uninstall` command in this release.

To disable Protected Paths in a target repo, remove:

```text
.git/hooks/pre-commit
```

If you no longer want the copied package files, optionally remove only files you
are sure came from this package and are not user-owned:

```text
protected-paths.cmd
protected-paths.ps1
tools/cli/
hooks/
governance/protected_paths.txt
approvals/APPROVAL_TOKEN_TEMPLATE.txt
```

Local proof receipts under `proofs/packets/` are user-owned local evidence.
Preserve or delete them by choice.

## Release Fingerprints

`RELEASE_FINGERPRINTS.sha256` is embedded in the package as a payload manifest.
It verifies shipped payload files only.

The final ZIP hash is recorded externally in the `.zip.sha256` sidecar during
the final release-build lane. Do not use older release-candidate hashes as final
artifact truth.

## Platform Posture

- Current v1.0.1 Windows cleanroom and bypass-regression validation: PASS
- Historical v1.0.0 CFD48 native macOS validation: PASS for the tested host/artifact only
- Current v1.0.1 native macOS validation: PENDING
- Unix shell hook included
- Native Linux validation: PENDING

Do not treat Linux as validated until this package is tested on a real Linux
host. Linux users should validate locally before relying on the Unix hook path.

## Limits And Responsibilities

AI Protected Paths is a local Git hook. Each developer or automation environment
must install it locally. A teammate who has not installed the hook will not get
the same local enforcement from this package.

Validated operating scope: local Git-based workflows using the included CLI
and hook setup. Behavior outside that context, including remote enforcement,
CI/CD pipeline enforcement, or team-wide policy systems, is not provided by
this package.

This v1 local hook does not guarantee team-wide or remote enforcement by itself.
It is not branch protection, not a CI/CD gate unless separately integrated, not
tamper-proof, not immutable, and not cryptographic security.

A user can bypass local Git hooks with `git commit --no-verify`. The tool is
designed to add deliberate review friction for normal workflows, not to stop
malicious actors or administrators.

This tool does not prevent file edits on disk, shell command execution, staging,
pushes, force pushes, or changes made outside Git commits. Use it with branch
protection, code review, CI policy, and access controls where those controls are
required.

Governance before automation.
